<?php
header('Content-Type: application/json');

// Mengambil input dari frontend (JSON)
$input = json_decode(file_get_contents('php://input'), true);
$userMessage = strtolower($input['message'] ?? '');

// Basis Pengetahuan (Knowledge Base)
// Anda bisa membuat ini lebih canggih, misalnya dari database
$knowledgeBase = [
    'halo' => 'Halo! Ada yang bisa saya bantu tentang rnara.id?',
    'hai' => 'Hai! Ada yang bisa saya bantu tentang rnara.id?',
    'apa itu rnara.id' => 'rnara.id adalah perusahaan yang bergerak di bidang web development, web consultant, dan desain grafis.',
    'layanan' => 'Kami menyediakan layanan web development (pembuatan website), web consultant (konsultasi pengembangan web), dan desain grafis.',
    'jasa' => 'Kami menyediakan layanan web development (pembuatan website), web consultant (konsultasi pengembangan web), dan desain grafis.',
    'web development' => 'Layanan web development kami meliputi pembuatan website custom, e-commerce, portal, dan aplikasi web sesuai kebutuhan Anda.',
    'web consultant' => 'Sebagai web consultant, kami membantu Anda merencanakan, mengembangkan, dan mengoptimalkan strategi web Anda.',
    'desain grafis' => 'Layanan desain grafis kami mencakup desain logo, branding, materi promosi, dan desain UI/UX untuk website Anda.',
    'lokasi' => 'Kami beroperasi secara online, namun tim kami tersebar di berbagai wilayah termasuk Surakarta, Indonesia.',
    'kontak' => 'Anda bisa menghubungi kami melalui email di info@rnara.id atau kunjungi halaman kontak di website kami untuk detail lebih lanjut.',
    'email' => 'Email kami adalah info@rnara.id.',
    'terima kasih' => 'Sama-sama! Ada lagi yang bisa saya bantu?',
    'siapa kamu' => 'Saya adalah chatbot otomatis rnara.id yang siap membantu Anda dengan informasi perusahaan.',
    'harga' => 'Untuk informasi harga, silakan hubungi kami langsung dengan detail proyek Anda agar kami bisa memberikan penawaran yang tepat.',
    // Tambahkan lebih banyak pertanyaan dan jawaban di sini
];

$reply = 'Maaf, saya tidak mengerti pertanyaan Anda. Bisakah Anda mengulanginya atau bertanya tentang layanan kami (web development, web consultant, desain grafis) atau informasi umum tentang rnara.id?';

// Mencari jawaban di basis pengetahuan
foreach ($knowledgeBase as $question => $answer) {
    if (strpos($userMessage, $question) !== false) {
        $reply = $answer;
        break;
    }
}

// Jika tidak ada jawaban spesifik, coba respon dengan pertanyaan kunci
if ($reply == 'Maaf, saya tidak mengerti pertanyaan Anda. Bisakah Anda mengulanginya atau bertanya tentang layanan kami (web development, web consultant, desain grafis) atau informasi umum tentang rnara.id?') {
    if (strpos($userMessage, 'web') !== false || strpos($userMessage, 'website') !== false) {
        $reply = 'Apakah Anda ingin tahu tentang layanan web development atau web consultant kami?';
    } elseif (strpos($userMessage, 'desain') !== false || strpos($userMessage, 'grafis') !== false) {
        $reply = 'Kami memiliki layanan desain grafis. Ingin tahu lebih banyak?';
    } elseif (strpos($userMessage, 'perusahaan') !== false || strpos($userMessage, 'rnara') !== false) {
        $reply = 'rnara.id adalah perusahaan di bidang web development, web consultant, dan desain grafis.';
    }
}


echo json_encode(['reply' => $reply]);
?>