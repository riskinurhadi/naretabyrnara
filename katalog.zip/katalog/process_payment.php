<?php
session_start();

// Periksa apakah ada data POST dari formulir checkout
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    // Jika tidak ada data yang valid, arahkan kembali ke halaman utama
    header('Location: index.php');
    exit;
}

// Mengambil data pelanggan dari formulir
$nama = htmlspecialchars($_POST['nama']);
$email = htmlspecialchars($_POST['email']);
$alamat = htmlspecialchars($_POST['alamat']);
$telepon = htmlspecialchars($_POST['telepon']);

// Mengambil data keranjang dari sesi
$cart = $_SESSION['cart'];
$totalPrice = 0;

// Menghitung total harga
foreach ($cart as $item) {
    $totalPrice += $item['price'] * $item['quantity'];
}

// =========================================================
// == DI SINI ADALAH TEMPAT INTEGRASI DENGAN PAYMENT GATEWAY ==
// =========================================================

// INFORMASI PENTING:
// Untuk mendapatkan API key dan informasi lainnya, Anda harus mendaftar
// di website penyedia payment gateway (seperti Midtrans, Xendit, dll).
// Setelah mendaftar, Anda akan mendapatkan "Server Key" dan "Client Key"
// dari dashboard mereka. Key ini bersifat RAHASIA dan tidak boleh disebarkan.

// Contoh konfigurasi API key (gunakan Server Key dari dashboard Anda)
const API_SERVER_KEY = 'Mid-server-nlajntIhIxoH2q-iD9-751iK'; // Ganti dengan Server Key Anda
const API_BASE_URL = 'https://api.midtrans.com/v2/charge'; // URL API Midtrans

// =========================================================
// === SIMULASI PEMANGGILAN API PAYMENT GATEWAY DENGAN QRIS ===
// =========================================================

// Siapkan data payload yang akan dikirim ke API
$payload = [
    'payment_type' => 'qris', // Kita pilih metode QRIS
    'transaction_details' => [
        'order_id'    => 'ORD-' . uniqid(), // ID pesanan yang unik
        'gross_amount' => $totalPrice,
    ],
    'customer_details'    => [
        'first_name' => $nama,
        'email'      => $email,
        'phone'      => $telepon,
        'shipping_address' => [
            'address' => $alamat
        ]
    ],
    'item_details' => [], // Anda bisa tambahkan detail item jika diperlukan
];

// Di sini Anda akan menggunakan library resmi atau cURL untuk memanggil API
// Contoh dengan cURL (ini hanya ilustrasi, perlu disesuaikan):
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, API_BASE_URL);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Basic ' . base64_encode(API_SERVER_KEY . ':')
]);
$response = curl_exec($ch);
curl_close($ch);
$apiResponse = json_decode($response, true);

// --- SIMULASI RESPON DARI API ---
// Asumsikan API merespons dengan URL untuk menampilkan QRIS
$apiResponse = [
    'status_code' => '201',
    'status_message' => 'Success, transaction is created',
    'transaction_id' => 'abcde12345',
    'actions' => [
        [
            'name' => 'generate-qr-code',
            'url' => 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=https://mockup.midtrans.com/va/qr-code/test_qr_code_url' // URL QRIS dari API
        ]
    ]
];

// =========================================================
// === SETELAH MENDAPATKAN RESPON DARI PAYMENT GATEWAY ===
// =========================================================

// Cek apakah API merespons dengan sukses
if (isset($apiResponse['status_code']) && $apiResponse['status_code'] === '201') {
    // Ambil URL QRIS dari respons API
    $qrisUrl = $apiResponse['actions'][0]['url'];

    // Hapus keranjang setelah data pesanan dikirim ke payment gateway
    unset($_SESSION['cart']);

    // Arahkan pengguna ke halaman yang menampilkan QRIS
    // Kita akan membuat halaman ini sekarang.
    header('Location: show_qris.php?qris_url=' . urlencode($qrisUrl) . '&order_id=' . $apiResponse['transaction_id']);
    exit;
} else {
    // Jika ada error dari API
    $errorMessage = isset($apiResponse['status_message']) ? $apiResponse['status_message'] : 'Terjadi kesalahan tidak terduga.';
    echo "Terjadi kesalahan saat memproses pembayaran. Pesan dari API: " . $errorMessage;
    echo "<br><a href='checkout.php'>Kembali ke Checkout</a>";
    exit;
}
?>
